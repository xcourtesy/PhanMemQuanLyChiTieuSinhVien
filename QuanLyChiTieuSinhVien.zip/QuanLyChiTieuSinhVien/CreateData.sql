USE `qlchitieusinhvien`;
SET SQL_SAFE_UPDATES = 0;
DELETE FROM `Vi` WHERE true;
INSERT INTO `Vi`(`ID`,`Ten`,`LoaiTien`) VALUES (1,'Sinh Hoạt', 'vnđ');
INSERT INTO `Vi`(`ID`,`Ten`,`LoaiTien`) VALUES (2,'Học Phí', 'vnđ');

DELETE FROM `LoaiThuChi` WHERE true;

INSERT INTO `LoaiThuChi`(`ID`,`Ten`,`IDVi`,`IsLoaiCon`,`IDLoaiCha`,`IsLoaiThu`) VALUES(1,'Gia Đình',1,0,NULL,1);
INSERT INTO `LoaiThuChi`(`ID`,`Ten`,`IDVi`,`IsLoaiCon`,`IDLoaiCha`,`IsLoaiThu`) VALUES(2,'Hóa Đơn & Dịch Vụ',1,0,NULL,0);
INSERT INTO `LoaiThuChi`(`ID`,`Ten`,`IDVi`,`IsLoaiCon`,`IDLoaiCha`,`IsLoaiThu`) VALUES(3,'Thuê Nhà',1,1,2,0);
INSERT INTO `LoaiThuChi`(`ID`,`Ten`,`IDVi`,`IsLoaiCon`,`IDLoaiCha`,`IsLoaiThu`) VALUES(4,'Điện',1,1,2,0);
INSERT INTO `LoaiThuChi`(`ID`,`Ten`,`IDVi`,`IsLoaiCon`,`IDLoaiCha`,`IsLoaiThu`) VALUES(5,'Nước',1,1,2,0);
INSERT INTO `LoaiThuChi`(`ID`,`Ten`,`IDVi`,`IsLoaiCon`,`IDLoaiCha`,`IsLoaiThu`) VALUES(6,'Internet',1,1,2,0);
INSERT INTO `LoaiThuChi`(`ID`,`Ten`,`IDVi`,`IsLoaiCon`,`IDLoaiCha`,`IsLoaiThu`) VALUES(7,'Điện Thoại',1,1,2,0);
INSERT INTO `LoaiThuChi`(`ID`,`Ten`,`IDVi`,`IsLoaiCon`,`IDLoaiCha`,`IsLoaiThu`) VALUES(8,'Vé Xe Bus',1,1,2,0);
INSERT INTO `LoaiThuChi`(`ID`,`Ten`,`IDVi`,`IsLoaiCon`,`IDLoaiCha`,`IsLoaiThu`) VALUES(9,'Xe Máy',1,1,2,0);
INSERT INTO `LoaiThuChi`(`ID`,`Ten`,`IDVi`,`IsLoaiCon`,`IDLoaiCha`,`IsLoaiThu`) VALUES(10,'Chăm Sóc Cá Nhân',1,0,NULL,0);
INSERT INTO `LoaiThuChi`(`ID`,`Ten`,`IDVi`,`IsLoaiCon`,`IDLoaiCha`,`IsLoaiThu`) VALUES(11,'Thời Trang',1,1,10,0);
INSERT INTO `LoaiThuChi`(`ID`,`Ten`,`IDVi`,`IsLoaiCon`,`IDLoaiCha`,`IsLoaiThu`) VALUES(12,'Sở Thích',1,1,10,0);
INSERT INTO `LoaiThuChi`(`ID`,`Ten`,`IDVi`,`IsLoaiCon`,`IDLoaiCha`,`IsLoaiThu`) VALUES(13,'Sức Khỏe',1,1,10,0);
INSERT INTO `LoaiThuChi`(`ID`,`Ten`,`IDVi`,`IsLoaiCon`,`IDLoaiCha`,`IsLoaiThu`) VALUES(14,'Ăn Uống',1,0,NULL,0);
INSERT INTO `LoaiThuChi`(`ID`,`Ten`,`IDVi`,`IsLoaiCon`,`IDLoaiCha`,`IsLoaiThu`) VALUES(15,'Ăn Ngoài',1,1,14,0);
INSERT INTO `LoaiThuChi`(`ID`,`Ten`,`IDVi`,`IsLoaiCon`,`IDLoaiCha`,`IsLoaiThu`) VALUES(16,'Gạo',1,1,14,0);
INSERT INTO `LoaiThuChi`(`ID`,`Ten`,`IDVi`,`IsLoaiCon`,`IDLoaiCha`,`IsLoaiThu`) VALUES(17,'Thịt Trứng',1,1,14,0);
INSERT INTO `LoaiThuChi`(`ID`,`Ten`,`IDVi`,`IsLoaiCon`,`IDLoaiCha`,`IsLoaiThu`) VALUES(18,'Nước',1,1,14,0);
INSERT INTO `LoaiThuChi`(`ID`,`Ten`,`IDVi`,`IsLoaiCon`,`IDLoaiCha`,`IsLoaiThu`) VALUES(19,'Rau',1,1,14,0);
INSERT INTO `LoaiThuChi`(`ID`,`Ten`,`IDVi`,`IsLoaiCon`,`IDLoaiCha`,`IsLoaiThu`) VALUES(20,'Bạn Bè & Người Yêu',1,0,NULL,0);
INSERT INTO `LoaiThuChi`(`ID`,`Ten`,`IDVi`,`IsLoaiCon`,`IDLoaiCha`,`IsLoaiThu`) VALUES(21,'Đi Chơi',1,1,20,0);
INSERT INTO `LoaiThuChi`(`ID`,`Ten`,`IDVi`,`IsLoaiCon`,`IDLoaiCha`,`IsLoaiThu`) VALUES(22,'Đám Cưới',1,1,20,0);
INSERT INTO `LoaiThuChi`(`ID`,`Ten`,`IDVi`,`IsLoaiCon`,`IDLoaiCha`,`IsLoaiThu`) VALUES(23,'Quà Tặng',1,1,20,0);


INSERT INTO `LoaiThuChi`(`ID`,`Ten`,`IDVi`,`IsLoaiCon`,`IDLoaiCha`,`IsLoaiThu`) VALUES(24,'Gia Đình',2,0,NULL,1);
INSERT INTO `LoaiThuChi`(`ID`,`Ten`,`IDVi`,`IsLoaiCon`,`IDLoaiCha`,`IsLoaiThu`) VALUES(25,'Học Phí Đại Học',2,0,NULL,0);
INSERT INTO `LoaiThuChi`(`ID`,`Ten`,`IDVi`,`IsLoaiCon`,`IDLoaiCha`,`IsLoaiThu`) VALUES(26,'Học Lại',2,1,25,0);
INSERT INTO `LoaiThuChi`(`ID`,`Ten`,`IDVi`,`IsLoaiCon`,`IDLoaiCha`,`IsLoaiThu`) VALUES(27,'Học Ngoại Ngữ',2,0,NULL,0);
INSERT INTO `LoaiThuChi`(`ID`,`Ten`,`IDVi`,`IsLoaiCon`,`IDLoaiCha`,`IsLoaiThu`) VALUES(28,'Học Tiếng Anh',2,1,27,0);
INSERT INTO `LoaiThuChi`(`ID`,`Ten`,`IDVi`,`IsLoaiCon`,`IDLoaiCha`,`IsLoaiThu`) VALUES(29,'Thi TOEIC',2,1,27,0);


