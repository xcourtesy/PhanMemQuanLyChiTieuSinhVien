/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package quanlychitieusinhvien.Control;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.Vector;
import quanlychitieusinhvien.Model.DichVu;
import quanlychitieusinhvien.Model.KhoanThuChi;

/**
 *
 * @author WorkOnHust
 */
public class QuanLyDichVu{
    
    private int iDKhoanThuChi;
    private ArrayList<DichVu> listDichVu = new ArrayList<>();
    private ArrayList<DichVu> listDichVuChuaGhiDataBase = new ArrayList<>();
    
    // SQL connection
    private Connection conn = null;
    private PreparedStatement st = null;
    private ResultSet rs = null;
    private final String dbURL = "jdbc:mysql://localhost/qlchitieusinhvien?useUnicode=yes&characterEncoding=UTF-8";
    private final String username = "root";
    private final String password = "root";
    private String sql;

    public QuanLyDichVu() {
    }
    public QuanLyDichVu(int iDKhoanThuChi) {
        this.iDKhoanThuChi = iDKhoanThuChi;
    }


    private boolean DocDataBase() {
       try {
            listDichVu.clear();
            conn = DriverManager.getConnection(dbURL, username, password);
//            if (conn != null) {
//             System.out.println("Kết nối thành công");
//            }
            sql = "SELECT * FROM `DichVu`";
            st = conn.prepareStatement(sql);
            rs = st.executeQuery();
            if (rs.isBeforeFirst() == false) {
           //     System.out.println("Dữ liệu trống");;
            }
            else
            {
                // Trong khi chưa hết dữ liệu
                while (rs.next()) {
                    listDichVu.add(new DichVu(rs.getInt("ID")
                                            ,rs.getInt("IDKhoanThuChi")
                                            ,rs.getString("LoaiDichVu")
                                            ,rs.getDate("NgayBatDau")
                                            ,rs.getDate("NgayKetThuc")
                                            ,rs.getString("GhiChu")));
                }
            }
            st.close();
            conn.close();
//            System.out.println("Đóng kết nối");
            return true;
        } catch (Exception e) {
          return false;
        }    
    }
    
    private boolean DocDataBase(String s) {
       try {
            listDichVu.clear();
            conn = DriverManager.getConnection(dbURL, username, password);
//            if (conn != null) {
//             System.out.println("Kết nối thành công");
//            }
            st = conn.prepareStatement(s);
            rs = st.executeQuery();
            if (rs.isBeforeFirst() == false) {
           //     System.out.println("Dữ liệu trống");;
            }
            else
            {
                // Trong khi chưa hết dữ liệu
                while (rs.next()) {
                    listDichVu.add(new DichVu(rs.getInt("ID")
                                            ,rs.getInt("IDKhoanThuChi")
                                            ,rs.getString("LoaiDichVu")
                                            ,rs.getDate("NgayBatDau")
                                            ,rs.getDate("NgayKetThuc")
                                            ,rs.getString("GhiChu")));
                }
            }
            st.close();
            conn.close();
//            System.out.println("Đóng kết nối");
            return true;
        } catch (Exception e) {
          return false;
        }    
    }


    private boolean GhiDataBase(DichVu o) {
        try {
            conn = DriverManager.getConnection(dbURL, username, password);
//            if (conn != null) {
//             System.out.println("Kết nối thành công");
//            }

            
            sql = "INSERT INTO `DichVu`(`IDKhoanThuChi`,`LoaiDichVu`,`NgayBatDau`,`NgayKetThuc`, `GhiChu`) VALUES(?,?,?,?,?);";
            // Tạo đối tượng thực thi câu lệnh Select
            st = conn.prepareStatement(sql);
            st.setInt(1,o.getiDKhoanThuChi());
            st.setString(2, o.getLoaiDichVu());
            st.setDate(3, o.getNgayBatDau());
            st.setDate(4, o.getNgayKetThuc());
            st.setString(5, o.getGhiChu());
            // Thực thi
            st.executeUpdate();
            st.close();
            conn.close();
     //       System.out.println("Đóng kết nối");
            return true;
        } catch (Exception e) {
            e.printStackTrace();
          return false;
        } 
    }
    
    private boolean XoaDataBase(int iDDichVu) {
        try {
            conn = DriverManager.getConnection(dbURL, username, password);
            if (conn != null) {
//             System.out.println("Kết nối thành công");
            }

            
            sql = "DELETE FROM `DichVu`WHERE ID=?;";
            // Tạo đối tượng thực thi câu lệnh Select
            st = conn.prepareStatement(sql);
            st.setInt(1,iDDichVu);
            // Thực thi
            st.executeUpdate();
            st.close();
            conn.close();
//            System.out.println("Đóng kết nối");
            return true;
        } catch (Exception e) {
            e.printStackTrace();
          return false;
        } 
    }
    
    public void show()
    {
        for (DichVu i:listDichVu)
        {
            System.out.println(i.getiD()+" "+i.getiDKhoanThuChi()+" "+i.getLoaiDichVu()+" "+i.getNgayBatDau()+" "+i.getNgayKetThuc()+" "+i.getGhiChu());
        }
    }
    public void showTemporary()
    {
        for (DichVu i:listDichVuChuaGhiDataBase)
        {
            System.out.println(i.getiD()+" "+i.getiDKhoanThuChi()+" "+i.getLoaiDichVu()+" "+i.getNgayBatDau()+" "+i.getNgayKetThuc()+" "+i.getGhiChu());
        }
    }
    
    public void update()
    {

        String s = "SELECT * FROM `DichVu` WHERE NgayKetThuc > SUBDATE(DATE(NOW()), INTERVAL 15 DAY) AND IDKhoanThuChi = "+String.valueOf(iDKhoanThuChi);
        DocDataBase(s);
    }
    
    public void updateAll()
    {
        DocDataBase();
    }
    
    public void updateByIdVi(int iDVi)
    {
        String s = "SELECT * FROM `DichVu` WHERE NgayKetThuc >= DATE(NOW()) AND IDKhoanThuChi IN (SELECT ID FROM `KhoanThuChi` WHERE IDVi = "+String.valueOf(iDVi)+");";
        DocDataBase(s);
    }
    
    public void add(DichVu v)
    {
        GhiDataBase(v);
    }
    
    public void add(DichVu v, int idKhoanThuChi)
    {
        v.setiDKhoanThuChi(idKhoanThuChi);
        GhiDataBase(v);
    }
    
    public void remove(int pos)
    {
        XoaDataBase(listDichVu.get(pos).getiD());
    }
    
    public DichVu get(int pos)
    {
        return listDichVu.get(pos);
    }
    
    public int size()
    {
        return listDichVu.size();
    }
    
    public int indexOf(int iD)
    {
        for(int i = 0; i < listDichVu.size();i++)
        {
            if(listDichVu.get(i).getiD()==iD)
            {
                return i;
            }
        }
        return -1;
    }

}
