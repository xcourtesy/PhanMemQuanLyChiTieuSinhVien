/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package quanlychitieusinhvien.Control;

import java.sql.Connection;
import java.sql.Date;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import quanlychitieusinhvien.Model.KhoanThuChi;
import quanlychitieusinhvien.Model.LoaiThuChi;
import quanlychitieusinhvien.Model.Vi;

/**
 *
 * @author WorkOnHust
 */
public class QuanLyKhoanThuChi {
    private int iDVi;
    private ArrayList<KhoanThuChi> listKhoanThuChi = new ArrayList<>();
    
        // SQL connection
    private Connection conn = null;
    private PreparedStatement st = null;
    private ResultSet rs = null;
    private final String dbURL = "jdbc:mysql://localhost/qlchitieusinhvien?useUnicode=yes&characterEncoding=UTF-8";
    private final String username = "root";
    private final String password = "root";
    private String sql;

    public QuanLyKhoanThuChi(int iDVi) {
        this.iDVi = iDVi;
        
    }


    private boolean DocDataBase() {
        try {
            listKhoanThuChi.clear();
        //    System.out.println("DocDataBase");
            conn = DriverManager.getConnection(dbURL, username, password);
            if (conn != null) {
                
             //System.out.println("Kết nối thành công");
            }
            sql = "SELECT * FROM `KhoanThuChi` WHERE IDVi = " + String.valueOf(iDVi); // WHERE IDVi = " + String.valueOf(iDVi)
            st = conn.prepareStatement(sql);
            rs = st.executeQuery();
            if (rs.isBeforeFirst() == false) {
                //System.out.println("Dữ liệu trống");;
            }
            else
            {
                // Trong khi chưa hết dữ liệu
                while (rs.next()) {
                    listKhoanThuChi.add(new KhoanThuChi(rs.getInt("ID")
                                            ,rs.getInt("IDVi")
                                            ,rs.getLong("SoTien")
                                            ,rs.getInt("IDLoaiThuChi")
                                            ,rs.getDate("Ngay")
                                            ,rs.getString("GhiChu")));
                }
                
            }
            st.close();
            conn.close();
            //System.out.println("Đóng kết nối");
            return true;
        } catch (Exception e) {
          return false;
        }    
    }
    
    private boolean DocDataBase(String sql) {
        try {
            listKhoanThuChi.clear();
            //System.out.println("DocDataBase(sql)");
            conn = DriverManager.getConnection(dbURL, username, password);
            if (conn != null) {
            // System.out.println("Kết nối thành công");
            }
            st = conn.prepareStatement(sql);
            rs = st.executeQuery();
            if (rs.isBeforeFirst() == false) {
              //  System.out.println("Dữ liệu trống");;
            }
            else
            {
                // Trong khi chưa hết dữ liệu
                while (rs.next()) {
                    listKhoanThuChi.add(new KhoanThuChi(rs.getInt("ID")
                                            ,rs.getInt("IDVi")
                                            ,rs.getLong("SoTien")
                                            ,rs.getInt("IDLoaiThuChi")
                                            ,rs.getDate("Ngay")
                                            ,rs.getString("GhiChu")));
                }
            }
            st.close();
            conn.close();
           // System.out.println("Đóng kết nối");
            return true;
        } catch (Exception e) {
          return false;
        }    
    }


    private boolean GhiDataBase(KhoanThuChi o) {
       try {
        //   System.out.println("GhiDataBase(ob)");
            conn = DriverManager.getConnection(dbURL, username, password);
            if (conn != null) {
        //     System.out.println("Kết nối thành công");
            }

            
            sql = "INSERT INTO `KhoanThuChi`(`IDVi`,`SoTien`,`IDLoaiThuChi`,`Ngay`, `GhiChu`) VALUES(?,?,?,?,?);";
            // Tạo đối tượng thực thi câu lệnh Select
            st = conn.prepareStatement(sql);
            st.setInt(1,o.getiDVi());
            st.setLong(2, o.getSoTien());
            st.setInt(3, o.getiDLoaiThuChi());
            st.setDate(4, o.getNgay());
            st.setString(5, o.getGhiChu());
            // Thực thi
            st.executeUpdate();
            st.close();
            conn.close();
         //   System.out.println("Đóng kết nối");
            return true;
        } catch (Exception e) {
            e.printStackTrace();
          return false;
        }    
    }
    
    private boolean XoaDataBase(int iDKhoanThuChi) {
       try {
         //  System.out.println("XoaDataBase(id)");
            conn = DriverManager.getConnection(dbURL, username, password);
            if (conn != null) {
          //   System.out.println("Kết nối thành công");
            }

            sql = "DELETE FROM `KhoanThuChi`WHERE ID=?;";
            // Tạo đối tượng thực thi câu lệnh Select
            st = conn.prepareStatement(sql);
            st.setInt(1,iDKhoanThuChi);
            // Thực thi
            st.executeUpdate();
            st.close();
            conn.close();
         //   System.out.println("Đóng kết nối");
            return true;
        } catch (Exception e) {
            e.printStackTrace();
          return false;
        }    
    }
    
    public void show()
    {
        for (KhoanThuChi i:listKhoanThuChi)
        {
            System.out.println(i.getiD()+" "+i.getiDVi()+" "+i.getSoTien()+" "+i.getiDLoaiThuChi()+" "+i.getNgay()+" "+i.getGhiChu());
        }
    }
    
    public void updateAll()
    {
        DocDataBase();
    }
    
    public void updateMonth(int year, int month)
    {
        String sql = "SELECT * FROM `KhoanThuChi` WHERE MONTH(Ngay)="
                        +String.valueOf(month)
                        +" AND YEAR(Ngay) ="
                        +String.valueOf(year)
                        + " AND IDVi = "
                        +String.valueOf(iDVi);
        DocDataBase(sql);
    }
    
    public void updateYear(int year)
    {
        String sql = "SELECT * FROM `KhoanThuChi` WHERE YEAR(Ngay) ="
                        +String.valueOf(year)
                        +" AND IDVi = "
                        +String.valueOf(iDVi);
        DocDataBase(sql);
    }
    
    public void updateTatCaVi()
    {
        String sql = "SELECT * FROM `KhoanThuChi`";
        DocDataBase(sql);
        
    }
    
    public void add(KhoanThuChi v)
    {
        GhiDataBase(v);
    }
    
    public void remove(int pos)
    {
        XoaDataBase(listKhoanThuChi.get(pos).getiD());
    }
    
    public KhoanThuChi get(int pos)
    {
        return listKhoanThuChi.get(pos);
    }
    public KhoanThuChi getById(int id)
    {
        int index = indexOf(id);
        return listKhoanThuChi.get(index);
    }
    public int size()
    {
        return listKhoanThuChi.size();
    }
    
    public int indexOf(int iD)
    {
        for(int i = 0; i < listKhoanThuChi.size();i++)
        {
            if(listKhoanThuChi.get(i).getiD()==iD)
            {
                return i;
            }
        }
        return -1;
    }
    public long getTongTien(int iDLoaiThuChi,Date NgayBatDau,Date NgayKetThuc)
    {
        long TongTien = 0;
        try {
            conn = DriverManager.getConnection(dbURL, username, password);
            if (conn != null) {
            // System.out.println("Kết nối thành công");
            }
            if(iDLoaiThuChi == 0) // nếu băng 0 nghĩa là xét tất cả các loại
            {
                sql = "SELECT SUM(SoTien) FROM `KhoanThuChi` "
                        + "WHERE IDVi = ? " // id ví
                        + "AND Ngay >= ? " // ngày bắt đầu
                        + "AND Ngay <= ? " // ngày kết thúc 
                        + "AND (IDLoaiThuChi in (SELECT ID  FROM `LoaiThuChi` WHERE IsLoaiThu = 0))"; // chỉ xét loại chi
                st = conn.prepareStatement(sql);
                st.setInt(1, iDVi);
                st.setDate(2, NgayBatDau);
                st.setDate(3, NgayKetThuc);
            }
            else
            {
                sql = "SELECT SUM(SoTien) FROM `KhoanThuChi` "
                        + "WHERE IDVi = ? "
                        + "AND Ngay >= ? "
                        + "AND Ngay <= ? "
                        + "AND (IDLoaiThuChi in (SELECT ID  FROM `LoaiThuChi` WHERE IsLoaiThu = 0)) " 
                        + "AND (IDLoaiThuChi = ? OR IDLoaiThuChi IN (SELECT ID FROM `LoaiThuChi` WHERE IDLoaiCha = ?))"; // xét loại cụ thể và loại con tương ứng
                st = conn.prepareStatement(sql);
                st.setInt(1, iDVi);
                st.setDate(2, NgayBatDau);
                st.setDate(3, NgayKetThuc);
                st.setInt(4, iDLoaiThuChi);
                st.setInt(5, iDLoaiThuChi);

            }
            rs = st.executeQuery();
            rs.next();
            TongTien = rs.getLong(1);

            st.close();
            conn.close();
           // System.out.println("Đóng kết nối");
        } catch (Exception e) {
            e.printStackTrace();
        }    
        return TongTien;
    }
}
