/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package quanlychitieusinhvien.Control;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import quanlychitieusinhvien.Model.LoaiThuChi;
import quanlychitieusinhvien.Model.Vi;


/**
 *
 * @author WorkOnHust
 */
public class QuanLyLoaiThuChi{
    private final int iDVi;
    public ArrayList<LoaiThuChi> listLoaiThuChi = new ArrayList<>();
    
    // SQL connection
    private Connection conn = null;
    private PreparedStatement st = null;
    private ResultSet rs = null;
    private final String dbURL = "jdbc:mysql://localhost/qlchitieusinhvien?useUnicode=yes&characterEncoding=UTF-8";
    private final String username = "root";
    private final String password = "root";
    private String sql;

    public QuanLyLoaiThuChi(int IDVi) {
        this.iDVi = IDVi;
    }
    

    private boolean DocDataBase()
    {
        try {
            listLoaiThuChi.clear();
            conn = DriverManager.getConnection(dbURL, username, password);
            if (conn != null) {
         //    System.out.println("Kết nối thành công");
            }
            sql = "SELECT * FROM `LoaiThuChi` WHERE IDVi = "+String.valueOf(iDVi);
            st = conn.prepareStatement(sql);
            rs = st.executeQuery();
            if (rs.isBeforeFirst() == false) {
         //       System.out.println("Dữ liệu trống");;
            }
            else
            {
                // Trong khi chưa hết dữ liệu
                while (rs.next()) {
                    listLoaiThuChi.add(new LoaiThuChi(rs.getInt("ID")
                                            ,rs.getString("Ten")
                                            ,rs.getInt("IDVi")
                                            ,rs.getBoolean("IsLoaiCon")
                                            ,rs.getInt("IDLoaiCha")
                                            ,rs.getLong("GiaTriMacDinh")
                                            ,rs.getBoolean("IsLoaiThu")));
                }
            }
            st.close();
            conn.close();
          //  System.out.println("Đóng kết nối");
            return true;
        } catch (Exception e) {
          return false;
        }
    }
    

    private boolean GhiDataBase(LoaiThuChi o)
    {
        try {
            conn = DriverManager.getConnection(dbURL, username, password);
            if (conn != null) {
          //   System.out.println("Kết nối thành công");
            }

            
            sql = "INSERT INTO `LoaiThuChi`(`Ten`,`IDVi`,`IsLoaiCon`,`IDLoaiCha`,`IsLoaiThu`, `GiaTriMacDinh`) VALUES(?,?,?,?,?,?);";
            // Tạo đối tượng thực thi câu lệnh Select
            st = conn.prepareStatement(sql);
            st.setString(1,o.getTen());
            st.setInt(2, o.getiDVi());
            st.setBoolean(3, o.isLoaiCon());
            if (o.getiDCha() != 0)
                st.setInt(4,o.getiDCha());
            else
                st.setNull(4,java.sql.Types.INTEGER);
            st.setBoolean(5, o.isLoaiThu());
            if (o.getiDCha() != 0)
                st.setLong(6, o.getGiaTriMacDinh());
            else
                st.setNull(6,java.sql.Types.INTEGER);
            // Thực thi
            st.executeUpdate();
            st.close();
            conn.close();
       //     System.out.println("Đóng kết nối");
            return true;
        } catch (Exception e) {
            
          return false;
        }
    }
    
    private boolean XoaDataBase(int iDLoaiThuChi)
    {
        try {
            conn = DriverManager.getConnection(dbURL, username, password);
            if (conn != null) {
        //     System.out.println("Kết nối thành công");
            }

            
            sql = "DELETE FROM `LoaiThuChi`WHERE ID=?;";
            // Tạo đối tượng thực thi câu lệnh Select
            st = conn.prepareStatement(sql);
            st.setInt(1,iDLoaiThuChi);
            // Thực thi
            st.executeUpdate();
            st.close();
            conn.close();
       //     System.out.println("Đóng kết nối");
            return true;
        } catch (Exception e) {
             e.printStackTrace();
          return false;
        }
    }
    
    public void show()
    {
        DocDataBase();
        for (LoaiThuChi i:listLoaiThuChi)
        {
            System.out.println(i.getiD()+" "+i.getTen()+" "+i.getiDVi()+" "+i.isLoaiCon()+" "+i.getiDCha()+" "+i.getGiaTriMacDinh());
        }
    }
    
    public void updateAll()
    {
        DocDataBase();
    }
    
    public void add(LoaiThuChi v)
    {
        
        GhiDataBase(v);
        DocDataBase();
    }
    
    public void remove(int pos)
    {
        XoaDataBase(listLoaiThuChi.get(pos).getiD());
    }
    
    public LoaiThuChi get(int pos)
    {
        return listLoaiThuChi.get(pos);
    }
    
    public LoaiThuChi getById(int id)
    {
        int index = indexOf(id);
        return listLoaiThuChi.get(index);
    }
    
    
    public int size()
    {
        return listLoaiThuChi.size();
    }
    
    public ArrayList<LoaiThuChi> getListCha()
    {
        ArrayList<LoaiThuChi> cha = new ArrayList<>();
        for (LoaiThuChi i:listLoaiThuChi)
        {
            if(i.isLoaiCon()==false)
            {
                cha.add(i);
            }
        }
        return cha;
    }
    
    public ArrayList<LoaiThuChi> getListCon()
    {
        ArrayList<LoaiThuChi> con = new ArrayList<>();
        for (LoaiThuChi i:listLoaiThuChi)
        {
            if(i.isLoaiCon()==true)
            {
                con.add(i);
            }
        }
        return con;
    }
    
    public int indexOf(int iD)
    {
        for(int i = 0; i < listLoaiThuChi.size();i++)
        {
            if(listLoaiThuChi.get(i).getiD()==iD)
            {
                return i;
            }
        }
        return -1;
    }
    // lấy id loại thu chi của loại thu chi cha ứng với id của loại thu chi con
    // nếu id input là loại cha thì sẽ trả về giá trị bằng 0
    // nếu id input là không tồn tại thì trả về 0
    public int findIDLoaiCha(int idLoaiCon)
    {
        updateAll();
        int indexLoaiCon = indexOf(idLoaiCon);
        if(indexLoaiCon > -1)
        {
            return listLoaiThuChi.get(indexLoaiCon).getiDCha();
        }
        return 0;
    }
}
