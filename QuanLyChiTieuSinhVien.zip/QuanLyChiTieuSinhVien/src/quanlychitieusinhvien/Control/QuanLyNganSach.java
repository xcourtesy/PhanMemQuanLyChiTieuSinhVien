/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package quanlychitieusinhvien.Control;

import java.sql.Connection;
import java.sql.Date;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.text.DecimalFormat;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Vector;
import quanlychitieusinhvien.Model.NganSach;
import quanlychitieusinhvien.Model.Vi;

/**
 *
 * @author WorkOnHust
 */
public class QuanLyNganSach {
    private int iDVi;
    private ArrayList<NganSach> listNganSach= new ArrayList<>();
    private ArrayList<NganSach> listNganSachChuaGhiDataBase = new ArrayList<>();
    private QuanLyKhoanThuChi qlKhoanThuChi; // sử dụng để tính tổng tiền hiện tại
    private QuanLyLoaiThuChi qlLoaiThuChi; // sử dụng để kiểm tra ngân sách

    
    // SQL connection
    private Connection conn = null;
    private PreparedStatement st = null;
    private ResultSet rs = null;
    private final String dbURL = "jdbc:mysql://localhost/qlchitieusinhvien?useUnicode=yes&characterEncoding=UTF-8";
    private final String username = "root";
    private final String password = "root";
    private String sql;

    public QuanLyNganSach(int iDVi) {
        this.iDVi = iDVi;
        this.qlKhoanThuChi = new QuanLyKhoanThuChi(iDVi);
        this.qlLoaiThuChi = new QuanLyLoaiThuChi(iDVi);
        update();
        qlLoaiThuChi.updateAll();
    }

    public int getiDVi() {
        return iDVi;
    }

    public void setiDVi(int iDVi) {
        this.iDVi = iDVi;
    }
    
    

    private boolean DocDataBase()
    {
        try {
            listNganSach.clear();
            conn = DriverManager.getConnection(dbURL, username, password);
            if (conn != null) {
          //   System.out.println("Kết nối thành công");
            }
            sql = "SELECT * FROM `NganSach` WHERE IDVi = "+String.valueOf(iDVi);
            st = conn.prepareStatement(sql);
            rs = st.executeQuery();
            if (rs.isBeforeFirst() == false) {
         //       System.out.println("Dữ liệu trống");;
            }
            else
            {
                // Trong khi chưa hết dữ liệu
                while (rs.next()) {
                    listNganSach.add(new NganSach(rs.getInt("ID")
                                                  ,rs.getInt("IDVi")
                                                  ,rs.getInt("SoTien")
                                                  ,rs.getInt("IDLoaiThuChi")
                                                  ,rs.getDate("NgayBatDau")
                                                  ,rs.getDate("NgayKetThuc")));
                }
            }
            st.close();
            conn.close();
        //    System.out.println("Đóng kết nối");
            return true;
        } catch (Exception e) {
          return false;
        }
    }
 
    private boolean DocDataBase(String sql)
    {
        try {
            listNganSach.clear();
            conn = DriverManager.getConnection(dbURL, username, password);
            if (conn != null) {
          //   System.out.println("Kết nối thành công");
            }
            st = conn.prepareStatement(sql);
            rs = st.executeQuery();
            if (rs.isBeforeFirst() == false) {
          //      System.out.println("Dữ liệu trống");;
            }
            else
            {
                // Trong khi chưa hết dữ liệu
                while (rs.next()) {
                    listNganSach.add(new NganSach(rs.getInt("ID")
                                                  ,rs.getInt("IDVi")
                                                  ,rs.getInt("SoTien")
                                                  ,rs.getInt("IDLoaiThuChi")
                                                  ,rs.getDate("NgayBatDau")
                                                  ,rs.getDate("NgayKetThuc")));
                }
            }
            st.close();
            conn.close();
         //   System.out.println("Đóng kết nối");
            return true;
        } catch (Exception e) {
          return false;
        }
    }
 
    
    private boolean GhiDataBase(NganSach o)
    {
        try {
            conn = DriverManager.getConnection(dbURL, username, password);
            if (conn != null) {
         //    System.out.println("Kết nối thành công");
            }
            sql = "INSERT INTO `NganSach`(`IDVi`,`SoTien`,`IDLoaiThuChi`,`NgayBatDau`,`NgayKetThuc`)VALUES(?,?,?,?,?);";
            // Tạo đối tượng thực thi câu lệnh Select
            st = conn.prepareStatement(sql);
            st.setInt(1,o.getiDVi());
            st.setLong(2, o.getSoTien());
            if(o.getiDLoaiThuChi() == 0)
            {
                st.setNull(3,java.sql.Types.INTEGER);
            }
            else
            {
                st.setInt(3, o.getiDLoaiThuChi());
            }
            st.setDate(4, o.getNgayBatDau());
            st.setDate(5, o.getNgayKetThuc());

            // Thực thi
            st.executeUpdate();
            st.close();
            conn.close();
        //    System.out.println("Đóng kết nối");
            return true;
        } catch (Exception e) {
            e.printStackTrace();
          return false;
        }
    }
    
    private boolean XoaDataBase(int iDNganSach)
    {
        try {
            conn = DriverManager.getConnection(dbURL, username, password);
            if (conn != null) {
      //       System.out.println("Kết nối thành công");
            }
            sql = "DELETE FROM `NganSach`WHERE ID=?;";
            // Tạo đối tượng thực thi câu lệnh Select
            st = conn.prepareStatement(sql);
            st.setInt(1,iDNganSach);

            // Thực thi
            st.executeUpdate();
            st.close();
            conn.close();
      //      System.out.println("Đóng kết nối");
            return true;
        } catch (Exception e) {
            e.printStackTrace();
          return false;
        }
    }

    public void show()
    {
        for (NganSach i:listNganSach)
        {
            System.out.println(i.getiD()+" "+i.getiDVi()+" "+i.getSoTien()+" "+i.getiDLoaiThuChi()+" "+i.getNgayBatDau()+" "+i.getNgayKetThuc());
        }
    }
    
    public void update()
    {
        String sql = "SELECT * FROM `NganSach` WHERE NgayKetThuc > SUBDATE(DATE(NOW()), INTERVAL 15 DAY) AND IDVi = "+String.valueOf(iDVi);;
        DocDataBase(sql);
    }
    
    public void updateAll()
    {
        DocDataBase();
    }
    
    
    public void updateTatCaVi()
    {
        String sql = "SELECT * FROM `NganSach`";
        DocDataBase(sql);
    }
    public void add(NganSach v)
    {
        GhiDataBase(v);
    }

    public void remove(int pos)
    {
        XoaDataBase(listNganSach.get(pos).getiD());
    }
    
    public NganSach get(int pos)
    {
        return listNganSach.get(pos);
    }
    public int size()
    {
        return listNganSach.size();
    }

    public int indexOf(int iD)
    {
        for(int i = 0; i < listNganSach.size();i++)
        {
            if(listNganSach.get(i).getiD()==iD)
            {
                return i;
            }
        }
        return -1;
    }
    
    public long getTongTien(NganSach o)
    {
        qlKhoanThuChi.updateAll();
        return qlKhoanThuChi.getTongTien(o.getiDLoaiThuChi(), o.getNgayBatDau(), o.getNgayKetThuc());
    }
    
    
    public String thayDoiNganSach(int iDLoaiThuChi,Date ngayThucHien)
    {
        update();
        String result = "";
        qlLoaiThuChi.updateAll();
        for (NganSach o:listNganSach)
        {
            if(o.getNgayBatDau().compareTo(ngayThucHien) <= 0  // ngày bắt đầu ngân sách nhỏ hơn hoặc bằng ngày thực hiện khoản thu chi
                    && o.getNgayKetThuc().compareTo(ngayThucHien) >= 0) // và ngày kết thúc ngân sách lớn hơn hoặc bằng ngày thực hiện khoản thu chi
            {
                // idloaithuchi của ngân sách bằng null => xét
                // hoặc idloaithuchi của ngân sách trùng id loại thu chi của khoản đang xét => xét
                // hoặc idloaithuchi của ngân sách trùng id loại thu chi nhóm cha của khoản đang xét => xét
                if(o.getiDLoaiThuChi() == 0 
                        || o.getiDLoaiThuChi() == iDLoaiThuChi 
                        || o.getiDLoaiThuChi() == qlLoaiThuChi.findIDLoaiCha(iDLoaiThuChi))
                {
                    long soTienHienTai = qlKhoanThuChi.getTongTien(o.getiDLoaiThuChi()
                                                                    , o.getNgayBatDau()
                                                                    , o.getNgayKetThuc());
                    // so sánh và thêm thông báo
                    String mess;
                    // Chuyển Date sang các số int
                    LocalDate localDate = o.getNgayBatDau().toLocalDate();
                    String ngayBatDau = String.valueOf(localDate.getDayOfMonth())
                                        +'-'+String.valueOf(localDate.getMonthValue())
                                        +'-'+String.valueOf(localDate.getYear());
                    localDate = o.getNgayKetThuc().toLocalDate();
                    String ngayKetThuc = String.valueOf(localDate.getDayOfMonth())
                                        +'-'+String.valueOf(localDate.getMonthValue())
                                        +'-'+String.valueOf(localDate.getYear());
                    // Tìm tên loại thu chi của ngân sách
                    String tenLoaiThuChi = "";
                    if(o.getiDLoaiThuChi() == 0)
                    {
                        tenLoaiThuChi = "tất cả các loại thu chi";
                    }
                    else
                    {
                        tenLoaiThuChi = qlLoaiThuChi.getById(o.getiDLoaiThuChi()).getTen();
                    }
                    // kiểm tra xem đã chi quá mức hay chưa
                    if(soTienHienTai>o.getSoTien())
                    {
                        mess ="Bạn đã chi vượt quá "+(soTienHienTai-o.getSoTien())
                                +" vnđ của ngân sách cho "
                                + tenLoaiThuChi
                                +" từ ngày "
                                +ngayBatDau
                                +" đến ngày "
                                +ngayKetThuc;
                        
                    }
                    else
                    {
                        mess ="Bạn đã chi "+soTienHienTai
                                +" vnđ trong ngân sách "
                                + o.getSoTien()
                                +" vnđ cho "
                                + tenLoaiThuChi
                                +" từ ngày "
                                +ngayBatDau
                                +" đến ngày "
                                +ngayKetThuc;
                    }
                    result += mess + "\n";
                }
            }
            
        }
        return result;
    }
    
    public Vector<String> getRowTable(int pos)
    {

        Vector<String> s = new Vector();
        
                
        if(get(pos).getiDLoaiThuChi() == 0)
        {
            s.add("Tất cả các loại chi tiêu");// ứng với ngân sách cho toàn ví
        }
        else
        {
            s.add(qlLoaiThuChi.getById(get(pos).getiDLoaiThuChi()).getTen()); // Tên loại thu chi của ngân sách
        }
       
        // Chuyển Date sang các số int
        LocalDate localDate = get(pos).getNgayBatDau().toLocalDate();
        String ngayBatDau = String.valueOf(localDate.getDayOfMonth())
                            +'-'+String.valueOf(localDate.getMonthValue())
                            +'-'+String.valueOf(localDate.getYear());
        localDate = get(pos).getNgayKetThuc().toLocalDate();
        String ngayKetThuc = String.valueOf(localDate.getDayOfMonth())
                            +'-'+String.valueOf(localDate.getMonthValue())
                            +'-'+String.valueOf(localDate.getYear());
        
        s.add(ngayBatDau);
        s.add(ngayKetThuc);
        
        // Số tiền trong ngân sách
        long soTienTrongNganSach = get(pos).getSoTien();
        s.add(String.valueOf(soTienTrongNganSach)); 
        
        // Số tiền đã chi
        long soTienDaChi = 0;
        soTienDaChi = getTongTien(get(pos));
        s.add(String.valueOf(soTienDaChi));
        
        // Số dư ngân sách
        long soDuTrongNganSach = soTienTrongNganSach - soTienDaChi ;
        s.add(String.valueOf(soDuTrongNganSach));
        
        //Tỉ lệ chi (%)
        Double tilechi = 0.0;
        if(get(pos).getSoTien()>0)
            tilechi = soTienDaChi*100.0/get(pos).getSoTien();
        DecimalFormat df = new DecimalFormat("#.00");
        String tile = df.format(tilechi);
        if(tilechi >= 1)
            s.add(tile+" %");
        else
            s.add("0"+tile+" %");
        
        // Trạng thái
        // Lấy tháng năm hiện tại
        Calendar currenttime = Calendar.getInstance();
        currenttime.set(Calendar.HOUR_OF_DAY, 0);
        currenttime.set(Calendar.MINUTE, 0);
        currenttime.set(Calendar.SECOND, 0);
        currenttime.set(Calendar.MILLISECOND, 0);
        Date nowDate = new Date((currenttime.getTime()).getTime());

        // Trạng thái ngân sách
        if(nowDate.compareTo(get(pos).getNgayKetThuc())<=0)
        {
            s.add("Đang hoạt động");
        }
        else
        {
            s.add("Kết thúc");
        }

        
        return s;
    }
}
