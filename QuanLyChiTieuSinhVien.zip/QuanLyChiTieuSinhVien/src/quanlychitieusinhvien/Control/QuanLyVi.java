/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package quanlychitieusinhvien.Control;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import quanlychitieusinhvien.Model.*;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.time.LocalDate;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JFileChooser;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.CreationHelper;

import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

/**
 *
 * @author WorkOnHust
 */
public class QuanLyVi{
    
    private ArrayList<Vi> listVi = new ArrayList<>();
    
    // SQL connection
    private Connection conn = null;
    private PreparedStatement st = null;
    private ResultSet rs = null;
    private final String dbURL = "jdbc:mysql://localhost/qlchitieusinhvien?useUnicode=yes&characterEncoding=UTF-8";
    private final String username = "root";
    private final String password = "root";
    private String sql;
    private String fileTaoDuLieuGoc = "CreateData.sql";
    
    
    

    public QuanLyVi() {
        
        
    }
    
 
    private boolean DocDataBase()
    {
        try {
            listVi.clear();
            conn = DriverManager.getConnection(dbURL, username, password);
            if (conn != null) {
         //    System.out.println("Kết nối thành công");
            }
            sql = "SELECT * FROM `Vi`;";
            st = conn.prepareStatement(sql);
            rs = st.executeQuery();
            if (rs.isBeforeFirst() == false) {
         //       System.out.println("Dữ liệu trống");;
            }
            else
            {
                // Trong khi chưa hết dữ liệu
                while (rs.next()) {
                    listVi.add(new Vi(rs.getInt("ID"),rs.getString("Ten"),rs.getString("LoaiTien")));
                }
            }
            st.close();
            conn.close();
        //    System.out.println("Đóng kết nối");
            return true;
        } catch (Exception e) {
          return false;
        }
    }
    
    

    private boolean GhiDataBase(Vi o)
    {
        try {
            conn = DriverManager.getConnection(dbURL, username, password);
            if (conn != null) {
        //     System.out.println("Kết nối thành công");
            }

            
            sql = "INSERT INTO `Vi`(`Ten`,`LoaiTien`) VALUES(?,?);";
            // Tạo đối tượng thực thi câu lệnh Select
            st = conn.prepareStatement(sql);
            st.setString(1,o.getTen());
            st.setString(2, o.getDonViTien());
            // Thực thi
            st.executeUpdate();
            st.close();
            conn.close();
      //      System.out.println("Đóng kết nối");
            return true;
        } catch (Exception e) {
          return false;
        }
    }
    
    private boolean XoaDataBase(int iDVi)
    {
        try {
            conn = DriverManager.getConnection(dbURL, username, password);
            if (conn != null) {
        //     System.out.println("Kết nối thành công");
            }

            
            sql = "DELETE FROM `Vi`WHERE ID=?;";
            // Tạo đối tượng thực thi câu lệnh Select
            st = conn.prepareStatement(sql);
            st.setInt(1,iDVi);
            // Thực thi
            st.executeUpdate();
            st.close();
            conn.close();
      //      System.out.println("Đóng kết nối");
            return true;
        } catch (Exception e) {
            e.printStackTrace();
          return false;
        }
    }
    
    public void KhoiPhucCoSoDuLieuGoc()
    {
        try {
//                String taoDuLieuGoc = "";
//                String temp;
//		File fileDir = new File(fileTaoDuLieuGoc);	
//		BufferedReader in = new BufferedReader(
//		   new InputStreamReader(
//                      new FileInputStream(fileDir), "UTF8"));  
//                while ((temp = in.readLine()) != null) {
//		   taoDuLieuGoc += temp +"\n";
//		}
//                in.close();
                //System.out.println(taoDuLieuGoc);
                try {
                    conn = DriverManager.getConnection(dbURL, username, password);
                    if (conn != null) {
                //     System.out.println("Kết nối thành công");
                    }
                    
                    String taoDuLieuGoc = "";
                    String temp;
                    File fileDir = new File(fileTaoDuLieuGoc);	
                    BufferedReader in = new BufferedReader(
                       new InputStreamReader(
                          new FileInputStream(fileDir), "UTF8"));  
                    while ((temp = in.readLine()) != null ) {
                        if(temp.equals("")==false)
                        {
                            taoDuLieuGoc += temp +"\n";
                            st = conn.prepareStatement(temp);
                             st.executeUpdate();
                        }
                    }
                    in.close();
                    
                    st.close();
                    conn.close();
                } catch (Exception e) {
                    e.printStackTrace();
                }
                
	    } 
	    catch (Exception e)
	    {
			System.out.println(e.getMessage());
	    }
    }
    
    public void xuatFileExcel(File fileToSave)
    {
        XSSFWorkbook workbook = new XSSFWorkbook(); 
        XSSFSheet sinhHoatSheet = workbook.createSheet("Ví Sinh Hoạt");
        sinhHoatSheet.autoSizeColumn(0);
        sinhHoatSheet.autoSizeColumn(1);
        sinhHoatSheet.autoSizeColumn(2);
        sinhHoatSheet.autoSizeColumn(3);
        XSSFSheet hocPhiSheet = workbook.createSheet("Ví Học Phí");
        hocPhiSheet.autoSizeColumn(0);
        hocPhiSheet.autoSizeColumn(1);
        hocPhiSheet.autoSizeColumn(2);
        hocPhiSheet.autoSizeColumn(3);
        
        CreationHelper createHelper = workbook.getCreationHelper();  
        CellStyle cellStyle = workbook.createCellStyle();  
            cellStyle.setDataFormat(  
                createHelper.createDataFormat().getFormat("dd/mm/yyyy"));  
        // Sheet ví sinh hoạt
        XSSFRow row = sinhHoatSheet.createRow(0);
        XSSFCell cell = row.createCell(0);
        cell.setCellValue("Ngày");
        cell = row.createCell(1);
        cell.setCellValue("Số Tiền");
        cell = row.createCell(2);
        cell.setCellValue("Loại Thu Chi");
        cell = row.createCell(3);
        cell.setCellValue("Ghi Chú");
        updateAll();
        int indexViSinhHoat = 0;
        Vi _vi = listVi.get(indexViSinhHoat);
        _vi.getQlKhoanThuChi().updateAll();
        _vi.getQlLoaiThuChi().updateAll();
        
        
        
        for(int rowindex = 1, i = 0 ; i < _vi.getQlKhoanThuChi().size();i++,rowindex++)
        {
            KhoanThuChi ktc = _vi.getQlKhoanThuChi().get(i);
            row = sinhHoatSheet.createRow(rowindex);
            
            cell = row.createCell(0);
            cell.setCellValue(ktc.getNgay());
            cell.setCellStyle(cellStyle);
            
            cell = row.createCell(1);
            cell.setCellValue(ktc.getSoTien());
            
            cell = row.createCell(2);
            cell.setCellValue(_vi.getQlLoaiThuChi().getById(ktc.getiDLoaiThuChi()).getTen());
            
            cell = row.createCell(3);
            cell.setCellValue(ktc.getGhiChu());
            
        }
        
        // Sheet ví học phí
        row = hocPhiSheet.createRow(0);
        cell = row.createCell(0);
        cell.setCellValue("Ngày");
        cell = row.createCell(1);
        cell.setCellValue("Số tiền");
        cell = row.createCell(2);
        cell.setCellValue("Loại thu chi");
        cell = row.createCell(3);
        cell.setCellValue("Ghi chú");
        updateAll();
        int indexViHocPhi = 1;
        _vi = listVi.get(indexViHocPhi);
        _vi.getQlKhoanThuChi().updateAll();
        _vi.getQlLoaiThuChi().updateAll();
        
        
        
        for(int rowindex = 1, i = 0 ; i < _vi.getQlKhoanThuChi().size();i++,rowindex++)
        {
            KhoanThuChi ktc = _vi.getQlKhoanThuChi().get(i);
            row = hocPhiSheet.createRow(rowindex);
            
            cell = row.createCell(0);
            cell.setCellValue(ktc.getNgay());
            cell.setCellStyle(cellStyle);
            
            cell = row.createCell(1);
            cell.setCellValue(ktc.getSoTien());
            
            cell = row.createCell(2);
            cell.setCellValue(_vi.getQlLoaiThuChi().getById(ktc.getiDLoaiThuChi()).getTen());
            
            cell = row.createCell(3);
            cell.setCellValue(ktc.getGhiChu());
            
        }
        
        
        
        
        FileOutputStream out;
        try {
            out = new FileOutputStream(fileToSave);
            workbook.write(out);
            out.close();
        } catch (FileNotFoundException ex) {
            Logger.getLogger(QuanLyVi.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IOException ex) {
            Logger.getLogger(QuanLyVi.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        
    }
    
    
    public void show()
    {
        DocDataBase();
        for (Vi i:listVi)
        {
            System.out.println(i.getiD()+" "+i.getTen()+" "+i.getDonViTien());
        }
    }
    
    public void updateAll()
    {
        DocDataBase();
    }
    
    public void add(Vi v)
    {
        GhiDataBase(v);
        DocDataBase();
    }
    
    public void remove(int pos)
    {
        XoaDataBase(listVi.get(pos).getiD());
    }
    
    public Vi get(int pos)
    {
        return listVi.get(pos);
    }
    
    public Vi getById(int id)
    {
        int index = indexOf(id);
        return listVi.get(index);
    }
    public int size()
    {
        return listVi.size();
    }
    
    public int indexOf(int iD)
    {
        for(int i = 0; i < listVi.size();i++)
        {
            if(listVi.get(i).getiD()==iD)
            {
                return i;
            }
        }
        return -1;
    }
}
