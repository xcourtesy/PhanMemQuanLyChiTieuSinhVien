/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package quanlychitieusinhvien.Control;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

/**
 *
 * @author Trinh Xinh
 */
public class tinhtongthuchi {
     public float getsodubandau(){
     float sum = 0;
     try{  
    Class.forName("com.mysql.cj.jdbc.Driver");  
    Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/qlchitieusinhvien","root","root");  
    //here sonoo is database name, root is username and password 

    //goi SQL statements
    Statement stmt=con.createStatement();  
    ResultSet rs=stmt.executeQuery("select * from ngansach ");  
    //run SQL statements
    while(rs.next()){  // get each of columns 
    sum +=  rs.getInt("SoTien"); 
    } 
    con.close();  // close the connection
    }catch(Exception e){ System.out.println(e);}  
    return sum;
     }  
    
    public float getsodusau(){
     float sumtienthuchi = 0;
     try{  
    Class.forName("com.mysql.cj.jdbc.Driver");  
    Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/qlchitieusinhvien","root","root");  
    //here sonoo is database name, root is username and password 
    //goi SQL statements
    Statement stmt=con.createStatement();  
    ResultSet rs=stmt.executeQuery("select * from khoanthuchi");  
    
    while(rs.next()){  
    float tien =  rs.getInt("SoTien");
    String loai = rs.getString("IDLoaiThuChi");
    Statement stmt2 = con.createStatement();  
    String st1 = "select * from loaithuchi where ID = "+"'"+ loai+"'";
    ResultSet rs2 = stmt2.executeQuery(st1); 
    rs2.first();
    boolean test =  rs2.getBoolean("isLoaiThu");
    if(test){
        sumtienthuchi +=  tien;
    }else{
        sumtienthuchi -=  tien;
    }
    } 
    con.close();  
    }catch(Exception e){ System.out.println(e);}  
     return sumtienthuchi;
     }
}
