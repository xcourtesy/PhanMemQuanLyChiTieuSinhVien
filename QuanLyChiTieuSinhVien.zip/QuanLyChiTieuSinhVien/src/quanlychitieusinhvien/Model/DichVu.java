/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package quanlychitieusinhvien.Model;

import java.sql.Date;

/**
 *
 * @author WorkOnHust
 */
public class DichVu {
    private int iD;
    private int iDKhoanThuChi;
    private String loaiDichVu;
    private Date ngayBatDau;
    private Date ngayKetThuc;
    private String ghiChu;

    public DichVu(int iD, int iDKhoanThuChi, String loaiDichVu, Date ngayBatDau, Date ngayKetThuc, String ghiChu) {
        this.iD = iD;
        this.iDKhoanThuChi = iDKhoanThuChi;
        this.loaiDichVu = loaiDichVu;
        this.ngayBatDau = ngayBatDau;
        this.ngayKetThuc = ngayKetThuc;
        this.ghiChu = ghiChu;
    }

    public DichVu(int iDKhoanThuChi, String loaiDichVu, Date ngayBatDau, Date ngayKetThuc, String ghiChu) {
        this.iDKhoanThuChi = iDKhoanThuChi;
        this.loaiDichVu = loaiDichVu;
        this.ngayBatDau = ngayBatDau;
        this.ngayKetThuc = ngayKetThuc;
        this.ghiChu = ghiChu;
    }

    public void setiDKhoanThuChi(int iDKhoanThuChi) {
        this.iDKhoanThuChi = iDKhoanThuChi;
    }

    public int getiD() {
        return iD;
    }

    public int getiDKhoanThuChi() {
        return iDKhoanThuChi;
    }

    public String getLoaiDichVu() {
        return loaiDichVu;
    }

    public Date getNgayBatDau() {
        return ngayBatDau;
    }

    public Date getNgayKetThuc() {
        return ngayKetThuc;
    }

    public String getGhiChu() {
        return ghiChu;
    }
    
    
    
}
