/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package quanlychitieusinhvien.Model;
import java.sql.Date;
import quanlychitieusinhvien.Control.QuanLyDichVu;

/**
 *
 * @author WorkOnHust
 */

public class KhoanThuChi {
    private int iD;
    private int iDVi;
    private int iDLoaiThuChi;
    private long soTien;
    private Date ngay;
    private String ghiChu;
    private QuanLyDichVu qlDichVu;

    public KhoanThuChi(int iDVi,  long soTien,int iDLoaiThuChi, Date ngay, String ghiChu) {
        this.iDVi = iDVi;
        this.iDLoaiThuChi = iDLoaiThuChi;
        this.soTien = soTien;
        this.ngay = ngay;
        this.ghiChu = ghiChu;
    }

    public QuanLyDichVu getQlDichVu() {
        return qlDichVu;
    }

    public KhoanThuChi(int iD, int iDVi,  long soTien,int iDLoaiThuChi, Date ngay, String ghiChu) {
        this.iD = iD;
        this.iDVi = iDVi;
        this.iDLoaiThuChi = iDLoaiThuChi;
        this.soTien = soTien;
        this.ngay = ngay;
        this.ghiChu = ghiChu;
        qlDichVu = new QuanLyDichVu(iD);
    }
    
    public KhoanThuChi()
    {
        this.iD = 0;
        qlDichVu = new QuanLyDichVu(iD);
    }

    public void setQlDichVu(QuanLyDichVu qlDichVu) {
        this.qlDichVu = qlDichVu;
    }
    


    public int getiD() {
        return iD;
    }

    public int getiDVi() {
        return iDVi;
    }

    public int getiDLoaiThuChi() {
        return iDLoaiThuChi;
    }

    public long getSoTien() {
        return soTien;
    }

    public Date getNgay() {
        return ngay;
    }

    public String getGhiChu() {
        return ghiChu;
    }
    
    
    
}
