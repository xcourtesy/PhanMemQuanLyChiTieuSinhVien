/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package quanlychitieusinhvien.Model;

/**
 *
 * @author WorkOnHust
 */
public class LoaiThuChi {
    private int         iD;
    private String      ten;
    private int         iDVi;
    private boolean     isLoaiCon;
    private int         iDCha;
    private long        giaTriMacDinh;
    private boolean     isLoaiThu;

    public LoaiThuChi(int iD, String ten, int iDVi, boolean isLoaiCon, int iDCha, long giaTriMacDinh, boolean thuHayChi) {
        this.iD = iD;
        this.ten = ten;
        this.iDVi = iDVi;
        this.isLoaiCon = isLoaiCon;
        this.iDCha = iDCha;
        this.giaTriMacDinh = giaTriMacDinh;
        this.isLoaiThu = thuHayChi; 
    }

    public LoaiThuChi(String ten, int iDVi, boolean isLoaiCon, int iDCha, long giaTriMacDinh, boolean isLoaiThu) {
        this.ten = ten;
        this.iDVi = iDVi;
        this.isLoaiCon = isLoaiCon;
        this.iDCha = iDCha;
        this.giaTriMacDinh = giaTriMacDinh;
        this.isLoaiThu = isLoaiThu;
    }

    public int getiD() {
        return iD;
    }

    public String getTen() {
        return ten;
    }

    public int getiDVi() {
        return iDVi;
    }

    public int getiDCha() {
        return iDCha;
    }

    public long getGiaTriMacDinh() {
        return giaTriMacDinh;
    }
    
    public boolean isLoaiCon()
    {
        return isLoaiCon;
    }
    
    public boolean isLoaiThu()
    {
        return isLoaiThu;
    }
    
    
    
}
