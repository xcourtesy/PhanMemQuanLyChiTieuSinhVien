/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package quanlychitieusinhvien.Model;

import java.sql.Date;

/**
 *
 * @author WorkOnHust
 */
public class NganSach {
    private int iD;
    private int iDVi;
    private long soTien;
    private int iDLoaiThuChi;
    private Date ngayBatDau;
    private Date ngayKetThuc;

    public NganSach(int iD, int iDVi, long soTien, int iDLoaiThuChi, Date ngayBatDau, Date ngayKetThuc) {
        this.iD = iD;
        this.iDVi = iDVi;
        this.soTien = soTien;
        this.iDLoaiThuChi = iDLoaiThuChi;
        this.ngayBatDau = ngayBatDau;
        this.ngayKetThuc = ngayKetThuc;
    }



    public NganSach(int iDVi, long soTien, int iDLoaiThuChi, Date ngayBatDau, Date ngayKetThuc) {
        this.iDVi = iDVi;
        this.soTien = soTien;
        this.iDLoaiThuChi = iDLoaiThuChi;
        this.ngayBatDau = ngayBatDau;
        this.ngayKetThuc = ngayKetThuc;
    }

    public int getiD() {
        return iD;
    }

    public int getiDVi() {
        return iDVi;
    }

    public int getiDLoaiThuChi() {
        return iDLoaiThuChi;
    }

    public long getSoTien() {
        return soTien;
    }

    public Date getNgayBatDau() {
        return ngayBatDau;
    }

    public Date getNgayKetThuc() {
        return ngayKetThuc;
    }
    
}
