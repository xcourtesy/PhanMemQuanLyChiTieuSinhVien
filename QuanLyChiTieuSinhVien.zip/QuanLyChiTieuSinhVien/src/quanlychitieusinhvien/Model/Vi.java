/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package quanlychitieusinhvien.Model;
import java.sql.Date;
import quanlychitieusinhvien.Control.QuanLyDichVu;
import quanlychitieusinhvien.Control.QuanLyKhoanThuChi;
import quanlychitieusinhvien.Control.QuanLyLoaiThuChi;
import quanlychitieusinhvien.Control.QuanLyNganSach;

/**
 *
 * @author WorkOnHust
 */
public class Vi {
    
    private int iD;
    private String ten;
    //private QuanLyNganSach qlNganSach;
    private String donViTien;
    private QuanLyKhoanThuChi qlKhoanThuChi;
    private QuanLyLoaiThuChi qlLoaiThuChi;
    private QuanLyNganSach qlNganSach;

    public QuanLyKhoanThuChi getQlKhoanThuChi() {
        return qlKhoanThuChi;
    }

    public QuanLyLoaiThuChi getQlLoaiThuChi() {
        return qlLoaiThuChi;
    }

    public QuanLyNganSach getQlNganSach() {
        return qlNganSach;
    }


    public Vi(String ten, String donViTien) {
        this.ten = ten;
        this.donViTien = donViTien;
    }

    public Vi(int iD, String ten, String donViTien) {
        this.iD = iD;
        this.ten = ten;
        this.donViTien = donViTien;
        ControlContructor();
    }

    public int getiD() {
        return iD;
    }

    public String getTen() {
        return ten;
    }

    public String getDonViTien() {
        return donViTien;
    }

    private void ControlContructor()
    {
        qlKhoanThuChi = new QuanLyKhoanThuChi(iD);
        qlLoaiThuChi = new QuanLyLoaiThuChi(iD);
        qlNganSach = new QuanLyNganSach(iD);
    }
    

    
}
