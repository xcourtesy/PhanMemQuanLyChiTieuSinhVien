/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package quanlychitieusinhvien;
import java.sql.Date;
import javax.swing.UIManager;
import quanlychitieusinhvien.Control.QuanLyDichVu;
import quanlychitieusinhvien.Control.QuanLyKhoanThuChi;
import quanlychitieusinhvien.Control.QuanLyLoaiThuChi;
import quanlychitieusinhvien.Control.QuanLyNganSach;
import quanlychitieusinhvien.Control.QuanLyVi;
import quanlychitieusinhvien.Model.DichVu;
import quanlychitieusinhvien.Model.LoaiThuChi;
import quanlychitieusinhvien.Model.NganSach;
import quanlychitieusinhvien.Model.Vi;
import quanlychitieusinhvien.Model.KhoanThuChi;
import quanlychitieusinhvien.View.*;

/**
 *
 * @author Nhom 16 lop Lap Trinh Nang Cao Ki 20191
 * @compary Dai hoc bach khoa Ha Noi
 */
public class QuanLyChiTieuSinhVien {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        try { 
            UIManager.setLookAndFeel("com.sun.java.swing.plaf.nimbus.NimbusLookAndFeel"); 
    } catch(Exception ignored){}
        MainFrame m = new MainFrame();
        m.setVisible(true);
        
        
    }
    
}
