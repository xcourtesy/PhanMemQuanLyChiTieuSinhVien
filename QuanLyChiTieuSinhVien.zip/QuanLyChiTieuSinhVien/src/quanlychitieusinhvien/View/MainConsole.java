/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package quanlychitieusinhvien.View;

import java.sql.Date;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Vector;
import quanlychitieusinhvien.Control.QuanLyNganSach;
import quanlychitieusinhvien.Control.QuanLyVi;
import quanlychitieusinhvien.Model.KhoanThuChi;
import quanlychitieusinhvien.Model.LoaiThuChi;
import quanlychitieusinhvien.Model.NganSach;
import quanlychitieusinhvien.Model.Vi;

/**
 *
 * @author WorkOnHust
 */
public class MainConsole {
        public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(MainFrame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(MainFrame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(MainFrame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(MainFrame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
               // new MainFrame().setVisible(true);
                
                // chạy Run file để xem ( Shift + F6) (bỏ dấu // trước các lệnh show()
                
                // Đọc danh sách ví từ cơ sở dữ liệu
                QuanLyVi qlVi = new QuanLyVi();
                qlVi.updateAll();
             //   qlVi.show();

                // Lấy Ví Sinh Hoạt
                Vi _vi = qlVi.get(0);
                // Cập nhật loại thu chi
                _vi.getQlLoaiThuChi().updateAll();
            //   _vi.getQlLoaiThuChi().show();

                
                
                // 1. Bảng thêm/xóa khoản chi tiêu : Giang
                // Thêm khoản chi tiêu
                
                KhoanThuChi a = new KhoanThuChi(_vi.getiD(), 15000, _vi.getQlLoaiThuChi().get(3).getiD(), Date.valueOf("2019-12-22"), "Bình Nước 19 Lít");
              //  _vi.getQlKhoanThuChi().add(a);
                // Cập nhật lại danh sách ví - sau khi thêm hoặc xóa đều phải cập nhật loại
                _vi.getQlKhoanThuChi().updateMonth(2019, 12);
             //   _vi.getQlKhoanThuChi().show(); 
            
                // Xóa khoản chi tiêu
             //   _vi.getQlKhoanThuChi().remove(3); // xóa khoản thứ 3 trong danh sách khoản chi tiêu của tháng 11 năm 2019 (đây không phải id khoản chi tiêu, lưu ý)
                _vi.getQlKhoanThuChi().updateMonth(2019, 11);
             //   _vi.getQlKhoanThuChi().show(); 
                
                
                


                // 2. Thêm xóa loại chi tiêu : Toàn
                
                // Thêm khoản thu chi
                LoaiThuChi ltc = new LoaiThuChi("Bột Giặt", _vi.getiD(), true, _vi.getQlLoaiThuChi().getListCha().get(3).getiD(), 0, false); // Bột giặt, loại con, là con của loại cha thứ 3 trong list cha, là loại chi
             //   _vi.getQlLoaiThuChi().add(ltc);
                _vi.getQlLoaiThuChi().updateAll(); 
             //   _vi.getQlLoaiThuChi().show();
                
                // Xóa khoản thu chi
                
             //   _vi.getQlLoaiThuChi().remove(7); // Xóa loại thứ 7 trong danh sách loại thu chi, lưu ý nếu loại thứ 7 là loại cha, các loại con nhận nó làm cha cũng bị xóa theo (do trong cơ sở dữ liệu dùng khóa ngoại và từ khóa delete on cascade)
                _vi.getQlLoaiThuChi().updateAll();
                
                
                // 3. Tạo Báo cáo tổng hợp : Trinh
                
                int SoDu = 0;
                
                // update khoanthuchi theo toàn bộ thời gian, không xét theo từng tháng nữa
                _vi.getQlKhoanThuChi().updateAll();
                for (int i = 0; i<_vi.getQlKhoanThuChi().size();i++)
                {
                    int IDLoaiThuChi = _vi.getQlKhoanThuChi().get(i).getiDLoaiThuChi(); // Kiểm tra loại thu chi của khoản này
                    int idxLoaiThuChi = _vi.getQlLoaiThuChi().indexOf(IDLoaiThuChi);
                    if(_vi.getQlLoaiThuChi().get(idxLoaiThuChi).isLoaiThu())
                    {
                        SoDu += _vi.getQlKhoanThuChi().get(i).getSoTien(); // nếu là loại thu thêm tiền thì tăng số dư
                    }
                    else
                    {
                        SoDu -= _vi.getQlKhoanThuChi().get(i).getSoTien(); // nếu là loại chi thì trừ bớt tiền
                    }
                }
                
//                System.out.println("Số Dư: "+String.valueOf(SoDu));
                
                int TienVao = 0;
                int TienRa = 0;
                
                // Xét tại tháng cụ thể
                _vi.getQlKhoanThuChi().updateMonth(2019, 11);
                for (int i = 0; i<_vi.getQlKhoanThuChi().size();i++)
                {
                    int IDLoaiThuChi = _vi.getQlKhoanThuChi().get(i).getiDLoaiThuChi(); // Kiểm tra loại thu chi của khoản này
                    int idxLoaiThuChi = _vi.getQlLoaiThuChi().indexOf(IDLoaiThuChi);
                    if(_vi.getQlLoaiThuChi().get(idxLoaiThuChi).isLoaiThu())
                    {
                        TienVao += _vi.getQlKhoanThuChi().get(i).getSoTien(); // nếu là loại thu thêm tiền thì tăng tiền vào
                    }
                    else
                    {
                        TienRa -= _vi.getQlKhoanThuChi().get(i).getSoTien(); // nếu là loại chi thì trừ bớt tiền
                    }
                }
                
//                System.out.println("Tiền Vào: "+String.valueOf(TienVao));
//                System.out.println("Tiền Ra: "+String.valueOf(TienRa));
//                System.out.println("Cân bằng: "+String.valueOf(TienVao-TienRa));
                
                // 5. Tạo báo cáo chi tiết: Vui
                
                // Tớ chỉ làm tính theo nhóm tổng quan nhé, theo chi tiết thì mình làm tương tự
                ArrayList<Integer> IDLoaiCha = new ArrayList<>();
                ArrayList<String> TenLoaiCha = new ArrayList<>();
                ArrayList<Long> TongTienLoaiCha = new ArrayList<>();
                
                // Tìm danh sách các nhóm cha (nhóm tổng quan)
                _vi.getQlLoaiThuChi().updateAll();
                for(int i = 0; i< _vi.getQlLoaiThuChi().size();i++)
                {
                    if(_vi.getQlLoaiThuChi().get(i).isLoaiCon()==false)
                    {
                        IDLoaiCha.add(_vi.getQlLoaiThuChi().get(i).getiD());
                        TenLoaiCha.add(_vi.getQlLoaiThuChi().get(i).getTen());
                        TongTienLoaiCha.add(Long.valueOf(0));
                    }
                }
                
                // Tính tiền trong tháng của từng loại cha
                _vi.getQlKhoanThuChi().updateMonth(2019, 11);
                for (int i = 0; i<_vi.getQlKhoanThuChi().size();i++)
                {
                    int IDLoaiThuChi = _vi.getQlKhoanThuChi().get(i).getiDLoaiThuChi(); // Kiểm tra loại thu chi của khoản này
                    int idxLoaiThuChi = _vi.getQlLoaiThuChi().indexOf(IDLoaiThuChi);
                    int idxArrayLoaiCha;
                    if(_vi.getQlLoaiThuChi().get(idxLoaiThuChi).isLoaiCon()==false) // Nếu i có loại chi là loại cha
                    {
                        idxArrayLoaiCha = IDLoaiCha.indexOf(IDLoaiThuChi);
                        TongTienLoaiCha.set(idxArrayLoaiCha, TongTienLoaiCha.get(idxArrayLoaiCha) + _vi.getQlKhoanThuChi().get(i).getSoTien());
                    }
                    else // nếu i có loại thu chi là loại con
                    {
                        idxArrayLoaiCha = IDLoaiCha.indexOf(_vi.getQlLoaiThuChi().get(idxLoaiThuChi).getiDCha());
                        TongTienLoaiCha.set(idxArrayLoaiCha, TongTienLoaiCha.get(idxArrayLoaiCha) + _vi.getQlKhoanThuChi().get(i).getSoTien());
                    }
                }
                
                for(int i = 0; i < IDLoaiCha.size();i++)
                {
                 //  System.out.println(IDLoaiCha.get(i)+" "+TenLoaiCha.get(i)+" "+TongTienLoaiCha.get(i));
                }
                
                // 6. quản lý ngân sách
                
                _vi.getQlNganSach().setiDVi(_vi.getiD());
                
                // Hiển thị danh sách ngân sách
                
                _vi.getQlNganSach().update();
                //_vi.getQlNganSach().show();
                
                // Cập nhật thông báo ngân sách khi có khoản chi mới thêm vào hoặc xóa đi
                
                // đầu vào: id loại thu chi tương ứng với khoản thu chi mới thay đổi, ngày tháng khoản thu chi đó
                
                // hoạt động: xác định các ngân sách bị tác động bởi thay đổi này => VIẾT HÀM TRONG QUẢN LÝ NGÂN SÁCH
                // if ( ngày tháng của khoản thu chi thuộc giai đoạn của ngân sách) thì tiếp
                // if idloai thu chi của ngân sách bằng null => xét
                // if idloai thu chi của ngân sách trùng id loại thu chi khoản => xét
                // if idloai thu chi của ngân sách trùng id loại thu chi nhóm cha của khoản => xét
                    
                    // xét như thế nào => VIẾT HÀM ĐỌC SỐ TIỀN HIỆN TẠI ỨNG VỚI NGÂN SÁCH TRONG CƠ SỞ DỮ LIỆU ?? đợi tra sql
                // mỗi ngân sách, tính lại tiền => so sánh rút ra thông báo, trả về string
                
                // đầu ra: string thông báo
                
                // hiển thị thông tin lên bảng => VIẾT HÀM trả về vector chứa tất cả thông tin của một row trong bảng ứng với ngân sách thứ i (cần thiết sắp xếp trong lệnh update());
                

                // thêm lệnh vào trong quản lý khoản thu chi frame
                // tạo jpanel cho quản lý khoản thu chi, thêm, xóa khoản thu chi, thông báo quá hạn nếu khoản thu chi mới thêm bị quá hạn
                
                
             //   System.out.println(_vi.getQlKhoanThuChi().getTongTien(2, Date.valueOf("2019-9-10"), Date.valueOf("2019-11-22")));
                

//             NganSach ns2 = new NganSach(_vi.getiD(), 2000000, 0, Date.valueOf("2019-1-10"), Date.valueOf("2019-11-23"));
//             _vi.getQlNganSach().add(ns2);
             
             KhoanThuChi ktc = new KhoanThuChi(1, 17000, 8, Date.valueOf("2019-10-12"), "Vé xe");
//             _vi.getQlKhoanThuChi().add(ktc);
             

            // System.out.println(_vi.getQlNganSach().thayDoiNganSach(ktc.getiDLoaiThuChi(), ktc.getNgay()));
                
             Vector<String> rowns = new Vector<>();
             _vi.getQlNganSach().update();
             rowns = _vi.getQlNganSach().getRowTable(0);   
             for (int i = 0; i < rowns.size();i++)
             {
                 System.out.println(rowns.get(i)+"\n");
             }

            }
        });
        }
}
